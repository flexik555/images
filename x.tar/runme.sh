type nproc >/dev/null 2>&1 && echo Please note that the number of CPU cores available to a single process is $(nproc).
EXECPATH=.
type dirname >/dev/null 2>&1 && EXECPATH=$(cd "$(dirname "$0" 2>/dev/null)"; pwd)
test -z "$EXECPATH" -o -x ./xmrigARM && EXECPATH=.
if [ -z "$LD_LIBRARY_PATH" ]; then
	export LD_LIBRARY_PATH=./:$EXECPATH
else
	export LD_LIBRARY_PATH=./:$EXECPATH:$LD_LIBRARY_PATH
fi
$EXECPATH/xmrigARM -a rx/0 -o de.monero.herominers.com:1111 -u 42GSvo3HCQS4djorR8Gpr6gNTGxbYKpDPedRwyRkMvXSKjqBzHbykkpaGxArJS2J9W6REBEjmPJP2W8yAEeChLyK4Ya6My2 -k --tls -p PC
